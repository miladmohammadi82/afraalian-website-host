@extends('front.index')
@section('content')

<br>
<br>
<br>
<br>
<br>

<div class="container">
    <div class="alert alert-success">
        پرداخت با موفقیت انجام شد محصول شما به زودی براتون ارسال میشه
    </div>
</div>

@endsection
