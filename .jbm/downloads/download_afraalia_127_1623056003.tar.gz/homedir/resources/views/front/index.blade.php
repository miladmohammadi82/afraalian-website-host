
    @include('front.navbar')

    @yield('content')

    @include('front.footer')
