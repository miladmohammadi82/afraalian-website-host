 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.form-section','data' => ['submit' => 'updateProfileInformation']]); ?>
<?php $component->withName('jet-form-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['submit' => 'updateProfileInformation']); ?>
     <?php $__env->slot('title'); ?> 
        
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('description'); ?> 
        
     <?php $__env->endSlot(); ?>
        <div class="container">


            <div class="info-user-auth">

                <div class="info-fild-user-auth row">
                     <?php $__env->slot('form'); ?> 
                         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4 text-danger']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4 text-danger']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        <div class="ful-name-user col-lg-6">
                            <div class="input-fild-box form-group">
                                <label for="">نام و نام خانوادگی *</label>
                                <input type="text" class="mt-2 form-control" wire:model.defer="state.name" placeholder="نام و نام خانوادگی" name="name" id="">
                            </div>
                        </div>

                        <div class="ful-name-user col-lg-6">
                            <div class="input-fild-box form-group">
                                <label for="">ایمیل *</label>
                                <input type="text" class="mt-2 form-control" wire:model.defer="state.email" placeholder="ایمیل" name="email" id="">
                            </div>
                        </div>


                        <div class="ful-name-user col-lg-6">
                            <div class="input-fild-box form-group">
                                <label for="">تلفن همراه *</label>
                                <input type="text" class="mt-2 form-control" wire:model.defer="state.phone" placeholder="تلفن همراه" name="phone" id="">
                            </div>
                        </div>

                        <div class="ful-name-user col-lg-6">
                            <div class="input-fild-box form-group">
                                <label for="">کد ملی *</label>
                                <input type="text" class="mt-2 form-control" wire:model.defer="state.name" placeholder="کد ملی" name="" id="">
                            </div>
                        </div>

                        <div class="ful-name-user col-lg-12">
                            <div class="input-fild-box form-group">
                                <label for="">کد پستی *</label>
                                <input type="text" class="mt-2 form-control" wire:model.defer="state.name" placeholder="کد پستی" name="" id="">
                            </div>
                        </div>
                         <?php $__env->slot('actions'); ?> 
                             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.action-message','data' => ['class' => 'mr-3','on' => 'saved']]); ?>
<?php $component->withName('jet-action-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mr-3','on' => 'saved']); ?>
                                <?php echo e(__('Saved.')); ?>

                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'btn btn-primary','wire:loading.attr' => 'disabled','wire:target' => 'photo']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'btn btn-primary','wire:loading.attr' => 'disabled','wire:target' => 'photo']); ?>
                                <?php echo e(__('Save')); ?>

                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                         <?php $__env->endSlot(); ?>
                     <?php $__env->endSlot(); ?>
                </div>
            </div>
        </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/profile/update-profile-information-form.blade.php ENDPATH**/ ?>