<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->yieldContent('metaTags'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> - عسل افراآلیان </title>
</head>

<body>

    <div id="app">
        <header class="header" id="header">
            <div class="container-fluid-for-mobile-header">
                <nav class="main-nav">
                    <div class="icon-mobile-right d-flex align-items-center">
                        <div class="menu-btn" :class="{ open:menuOpen }" @click="menuOpenshow">
                            <div class="menu-btn-burger"></div>
                        </div>
                    </div>

                    <div class="logo comp">
                        <h2>logo</h2>
                    </div>

                    <ul class="main-menu">

                        <li class="nav-link"><a href="/" class="a-nav-link active">خانه</a></li>

                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-link"><a href="#" class="a-nav-link"><?php echo e($category->title); ?><i
                                        class="fal fa-angle-down"></i></a>
                                <div class="dropdown">
                                    <ul>
                                        <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="dropdown-link"><a
                                                    href="<?php echo e(route('show.category.page', $childCategory->slug)); ?>"><?php echo e($childCategory->title); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <li class="nav-link"><a href="<?php echo e(route('about.page')); ?>" class="a-nav-link">درباره ما</a></li>
                        <li class="nav-link"><a href="<?php echo e(route('contact.page')); ?>" class="a-nav-link">تماس باما</a></li>
                    </ul>





                    <div class="right-menu d-flex">
                        <?php if(auth()->guard()->guest()): ?>
                            <div class="box-icon-user ml-2" >
                                <a href="<?php echo e(route('login')); ?>">
                                    <i class="far fa-sign-in" style="color:#006fd6"></i>
                                </a>
                            </div>

                            <div class="box-icon-user ml-2" style="background:#006fd6">
                                <a href="<?php echo e(route('register')); ?>">
                                    <i class="far fa-user-plus" style="color:#ffffff"></i>
                                </a>
                            </div>
                        <?php endif; ?>

                        <?php if(auth()->guard()->check()): ?>
                            <div class="box-icon-user ml-2" :class="{ openUser:openMenuUser }" @click="showUserMenu">
                                <i class="far fa-user-circle" style="color:#006fd6"></i>
                            </div>
                        <?php endif; ?>
                        <div class="search-section pl-3">
                            <div class="pl-3">
                                <a href="#"><i class="fal fa-search fa-lg text-dark"
                                        :class="{ 'fal fa-search-minus':searchBox }"
                                        @click.prevent="addSearchBox"></i></a>
                            </div>

                            
                            <div class="search_wrapper" :class="{ showSearchbox:searchBox }" style="display: block;">
                                <div>
                                    <form action="<?php echo e(route('search')); ?>" class="search-input-box" method="GET">
                                        <i class="far fa-search"></i>
                                        <input type="search" name="query" value="<?php echo e(request()->input('query')); ?>"
                                            placeholder="جستجو در افراآلیان" id="">
                                    </form>
                                </div>
                            </div>

                        </div>

                        <div class="sopping-cart pl-3">
                            <a href="<?php echo e(route('cart.page')); ?>">

                                <i class="fal fa-shopping-bag fa-lg text-dark"></i>


                                <div class="conter-shopping-cart" style="margin: -34px -6px;"><span><?php echo e(\Cart::getContent()->count()); ?></span></div>
                            </a>
                        </div>



                        <div class="buttons-register">
                            <?php if(auth()->guard()->guest()): ?>
                                <a href="<?php echo e(route('login')); ?>" class="btn-register-system ml-2"><i
                                        class="far fa-sign-in-alt fa-lg"></i>&nbsp;ورود</a>
                                <a href="<?php echo e(route('register')); ?>" class="btn-register-system"><i
                                        class="far fa-user-plus fa-lg"></i>&nbsp;ثبت نام</a>
                            <?php endif; ?>

                            <?php if(auth()->guard()->check()): ?>
                                <a class="cursor-pointer btn btn-profile-header"><i class="fa fa-user fa-gl"></i>&nbsp;محیط
                                    کاربری</a>
                                <div class="dropdown-user-panel-button">
                                    <div class="user-info-user-panel-button">
                                        <div class="image-user"></div>
                                        <div class="name-user"><a
                                                href="<?php echo e(route('profile.show')); ?>"><?php echo e(Auth::user()->name); ?></a></div>
                                        <ul class="list-info-action">
                                            <li class="mt-2">
                                                <a href="<?php echo e(route('profile.show')); ?>"><i
                                                        class="fa fa-user fa-1x"></i>&nbsp;پروفایل</a>
                                            </li>
                                            <li class="logout-list-profile-dropdown">
                                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <i class="far fa-sign-out-alt"></i>
                                                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                                this.closest('form').submit();">
                                                        <?php echo e(__('خروج')); ?>

                                                    </a>
                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                </nav>


            </div>

            <!-- Start menu mobile -->


            <div class="header-mobile" :class="{ showMenu:mobileMenu }">

                <div class="header-menu">
                    <h3 class="text-center">logoo</h3>
                    <form action="<?php echo e(route('search')); ?>" class="search-box-menu-mobile" method="GET">
                        <input type="text" name="query" value="<?php echo e(request()->input('query')); ?>"
                        placeholder="جستجو در افراآلیان">
                        <div class="input-group-append">
                            <button type="submit" id="searchsubmith" class="btn btn-search">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>





                <div class="items-menu-mobile">
                    <ul>
                        <li>
                            <a><span class="fas fa-home"></span>&nbsp;خانه</a>
                        </li>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a class="click-dropdown-mobile"><span class="fas fa-boxes"></span>&nbsp;<?php echo e($category->title); ?><span class="fas fa-chevron-down"></span></a>
                                <div class="dropdown-mobile" id="dropdown-mobile">
                                    <ul>
                                        <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route('show.category.page', $childCategory->slug)); ?>"><?php echo e($childCategory->title); ?></a></li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <li>
                            <a href="<?php echo e(route('profile.show.comments')); ?>"><span class="fas fa-comment-exclamation"></span>&nbsp;درباره ما</a>
                        </li>

                        <li>
                            <a href="<?php echo e(route('profile.show.comments')); ?>"><span class="fas fa-phone"></span>&nbsp;تماس با ما</a>
                        </li>

                    </ul>
                </div>

            </div>

            <div :class="{ igron:showIgron }" @click="menuOpenshow"></div>
            <!-- END menu mobile -->

            <?php if(auth()->guard()->check()): ?>
                <div class="menu-user" :class="{ 'user-show':showMenuUser }">
                    <div class="content-user">
                        <div class="header1">
                            <img class="avatar avatar-65 photo" src="<?php echo e(asset('assets/images_min/d41d8cd98f00b204e9800998ecf8427e-min.jpg')); ?>" height="65" width="65" loading="lazy">
                            <span class="user-name-login-for-mobile"><?php echo e(auth()->user()->name); ?></span>
                        </div>

                        <div class="items-user">
                            <ul>
                                <li>
                                    <a href="/profile"><span class="fas fa-user"></span>&nbsp;حساب کاربری</a>
                                </li>

                                <li>
                                    <a href="<?php echo e(route('orders.user.profile')); ?>"><span class="fas fa-box-check"></span>&nbsp;سفارشات من</a>
                                </li>

                                <li>
                                    <a href="<?php echo e(route('address.user.profile')); ?>"><span class="fas fa-map-marker-alt"></span>&nbsp;نشانی</a>
                                </li>

                                <li>
                                    <a href="<?php echo e(route('profile.show.comments')); ?>"><span class="fas fa-comments"></span>&nbsp;نظرات</a>
                                </li>

                                <li>
                                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn" style="color: #505763;padding: 0 !important;"><span class="fas fa-power-off"></span>&nbsp;خروج</button>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div :class="{'igrone-user-menu':showIgroneUser}" @click="showUserMenu"></div>
        </header>
<?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/front/navbar.blade.php ENDPATH**/ ?>