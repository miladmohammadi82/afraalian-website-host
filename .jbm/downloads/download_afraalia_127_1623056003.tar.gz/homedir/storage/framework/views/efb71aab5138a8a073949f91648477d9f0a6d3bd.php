<?php $__env->startSection('adminContent'); ?>

<br>
<br>
<br>
<br>
<br>
<br>

<div class="container">
    <h1 class="cathea">
        <span class="catheadlin">
            نظران محصولات
        </span>
    </h1>

    <?php if(!$comments): ?>
        <br>
        <div class="alert alert-danger">شماهیچ نظری برای محصولات ثبت نکرده اید</div>
    <?php endif; ?>
    <table class="content-table">
        <thead>
            <tr>
                <th>نام نویسنده</th>
                <th>ایمیل نویسنده</th>
                <th>متن نظر</th>
                <th>وضغیت</th>

            </tr>
        </thead>
        <tbody class="tbody-mobile">
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <tr class="comment-table-mobile">
                <td class="comment-table-mobile-td">
                    <h4>نام نویسنده</h4>&nbsp;
                    <?php echo e($comment->name); ?>

                </td>
                <td class="comment-table-mobile-td">
                    <h4>ایمیل نویسنده</h4>&nbsp;
                    <?php echo e($comment->email); ?>

                </td>
                <td class="comment-table-mobile-td">
                    <h4>متن نظر</h4>
                    <?php echo e($comment->body); ?>

                </td>
                <td class="comment-table-mobile-td">
                    <h4>وضغیت</h4>&nbsp;
                    <?php if($comment->status == 1): ?>
                        <span><span class="badge badge-success">تایید شده</span></span>
                    <?php endif; ?>
                    <?php if($comment->status == 0): ?>
                        <span><span class="badge badge-danger">تایید نشده</span></span>
                    <?php endif; ?>
                </td>

            </tr>




            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

    <h1 class="cathea">
        <span class="catheadlin">
            نظران مطالب
        </span>
    </h1>
    <?php if(!$articlesComment): ?>
    <br>
        <div class="alert alert-danger">شماهیچ نظری برای مطالب ثبت نکرده اید</div>
    <?php endif; ?>
    <table class="content-table">
        <thead>
            <tr>
                <th>نام نویسنده</th>
                <th>متن نظر</th>
                <th>وضغیت</th>

            </tr>
        </thead>
        <tbody class="tbody-mobile">
            <?php $__currentLoopData = $articlesComment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <tr class="comment-table-mobile">
                <td class="comment-table-mobile-td">
                    <h4>نام نویسنده</h4>&nbsp;
                    <?php echo e($comment->name); ?>

                </td>
                <td class="comment-table-mobile-td">
                    <h4>متن نظر</h4>
                    <?php echo e($comment->body); ?>

                </td>
                <td class="comment-table-mobile-td">
                    <h4>وضغیت</h4>&nbsp;
                    <?php if($comment->status == 1): ?>
                        <span><span class="badge badge-success">تایید شده</span></span>
                    <?php endif; ?>
                    <?php if($comment->status == 0): ?>
                        <span><span class="badge badge-danger">تایید نشده</span></span>
                    <?php endif; ?>
                </td>

            </tr>




            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/profile/comment/comments.blade.php ENDPATH**/ ?>