<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('metaTags'); ?>
    <meta property="og:type" content="article"/>
    <meta property="og:title" content="<?php echo e($article->name); ?>"/>
    <meta property="og:image" content="<?php echo e($article->index_image); ?>"/>
    <meta property="og:url" content="https://afraalian.com/article/<?php echo e($article->slug); ?>"/>
    <meta property="og:site_name" content="افرا آلیان"/>
<?php $__env->stopSection(); ?>

<br>
<br>
<br>
<br>
<br>
<br>

<div class="container">

    <div class="sections_group">

        <div class="d-flex align-items-center justify-content-between">
            <div class="group d-flex align-items-baseline">
                <div class="y_ic">
                    <i class="far fa-file-signature"></i>
                </div>
                <div class="article-title">
                    <h2><?php echo e($article->name); ?></h2>
                </div>
            </div>
            <div class="like-article-item d-flex">
                <a>
                    <div class="harts-like">
                    <a <?php if(auth()->guard()->guest()): ?> href="<?php echo e(route('redirect.auth.like.post')); ?>" <?php endif; ?> class="fal fa-heart text-danger single-page__like fa-2x <?php if($article->is_user_liked): ?> fas <?php endif; ?>"></a>
                </div></a>&nbsp;
                <div class="count-like-article" style="color: #444;"><?php echo e($articleCount); ?></div>
            </div>



        </div>
        <div class="description-article">
            <h2><?php echo $article->description; ?></h2>
        </div>
        <br>
        <hr>
        <br>
        <div class="writerStyleBox">
            <div class="sourcelinkpost">
                <ul>
                    <li> <i class="far fa-file-signature fa-lg"></i> نویسنده : <?php echo e($article->user->name); ?> </li>
                    <br>
                    <li> <i class="far fa-exclamation-circle fa-lg"></i> منبع : افرا آلیان</li>
                    <br>
                    <li><a href="https://modiresabz.com/wp-content/uploads/2021/01/26396n.pdf" class="btn green_bt">دانلود PDF</a></li>
                </ul>
            </div>
        </div>
    </div>

    
    <div class="content-comment-tab">
        <h1 class="title-comment-tab">نقد و برسی</h1>
        <br>
        <br>

        <?php echo $__env->make('back.pages.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <br>
        <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(route('create.new.comment-article', $article->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="comment-text">
                    <label for="body">نظر شما</label>
                    <div class="form-group">
                        <textarea placeholder="نظر خود را بنویسید..." name="body" id="body" cols="30" rows="10" class="form-control"></textarea>
                    </div>
                    <div class="d-flex justify-content-end">
                        <button type="submit" class="btn btn-primary">ارسال</button>
                    </div>
                </div>
            </form>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
            <p>برای ارسال نظر باید ابتدا <a href="<?php echo e(route('login')); ?>">وارد</a> شوید</p>
        <?php endif; ?>

        <div class="product-comments pt-5">
            <?php echo $__env->make('front.pages.comments.comment', ['comments' => $article->comments, 'article' => $article], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

    </div>

    



    

<section id="top-sale">
    <div class="container mt-3">
        <div class="row">
            <div class="col-12">
                <h4>
                    <span>جدید ترین مطالب</span>
                </h4>

                <div class="card-body">
                    <div class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $articlesNew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articleNew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="article-item">
                                <div class="panel-custom article-item-contents">
                                    <a href="<?php echo e(route('article.show.page', $articleNew->slug)); ?>">
                                        <div class="panel-body-custom">
                                            <img width="700" height="466" src="<?php echo e($articleNew->index_image); ?>" alt="">
                                        </div>
                                    </a>
                                    <div class="article-item-footer">
                                        <h4><?php echo e($articleNew->name); ?></h4>
                                        <div class="btns-action-article-item d-flex align-items-center justify-content-sm-around">
                                            <div class="like-article-item d-flex">
                                                <a>
                                                    <div class="harts-like">
                                                    <i class="fas fa-heart text-danger"></i>
                                                </div></a>&nbsp;
                                                <div class="count-like-article" style="color: #444;"><?php echo e($articleCount); ?></div>
                                            </div>
                                            <a class="btn d-flex align-items-center" href="<?php echo e(route('article.show.page', $articleNew->slug)); ?>">ادامه مطلب&nbsp;<i class="fas fa-chevron-left"></i></a>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        img{
            max-width: 100%;
        }


    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(".single-page__like").click(function () {
            fetch('<?php echo e(route("like.post", $article->slug)); ?>', {
                method: "post",
                headers: {
                    'X-CSRF-Token': '<?php echo e(csrf_token()); ?>'
                }
            }).then(()=> {
                $(this).toggleClass("fas")
            })

        })
    </script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/front/pages/article.blade.php ENDPATH**/ ?>