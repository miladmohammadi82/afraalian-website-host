<?php $__env->startSection('contentAdmin'); ?>

<br>
<br>
<br>
<br>
<br>

<div class="container">
    <div class="row mt-5">
        <div class="col-12">
            <?php echo $__env->make('back.pages.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">دسته بندی نظرات مقالات</h3>

                    <div class="card-tools">
                        <div class="input-group input-group-sm" style="width: 150px;">
                            <input type="text" name="table_search" class="form-control float-right" placeholder="جستجو">

                            <div class="input-group-append">
                                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                            </div>
                        </div>

                    </div>


                </div>
                <!-- /.card-header -->

                <div id="loading">
                    <vue-simple-spinner class="mt4" size="large" message="Loading..."></vue-simple-spinner>
                </div>
                <div class="card-body table-responsive p-0">
                    <table class="table table-hover" style="font-size: 16px;">
                        <tbody>
                            <tr>
                                <th>آیدی</th>
                                <th>نظر</th>
                                <th>نویسنده</th>
                                <th>برای محصول</th>
                                <th>وضعیت</th>
                                <th>تارییخ ساخت</th>
                            </tr>
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($comment->id); ?></td>
                                    <td><?php echo e($comment->body); ?></td>
                                    <td><?php echo e($comment->user->name); ?></td>
                                    <td><?php echo e($comment->article->name); ?></td>
                                    <td>
                                        <?php if($comment->status == 1): ?>
                                            <a href="<?php echo e(route('editComment.product-comment.admin.panel', $comment->id)); ?>" class="border-0"><span class="badge badge-success">تایید شده</span></a>
                                        <?php endif; ?>
                                        <?php if($comment->status == 0): ?>
                                            <a href="<?php echo e(route('editComment.product-comment.admin.panel', $comment->id)); ?>"><span class="badge badge-danger">تایید نشده</span></a>
                                        <?php endif; ?>

                                    </td>
                                    <td><?php echo e($comment->created_at); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('edit.product-comment.admin.panel', $comment->id)); ?>"
                                            class="btn btn-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>&nbsp;
                                        <form method="POST"
                                            action="<?php echo e(route('destroy.product-comment.admin.panel', $comment->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->

        </div>



    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/back/pages/articleComment/articles-comments.blade.php ENDPATH**/ ?>