<?php $__env->startSection('contentAdmin'); ?>

    <div class="container">
        <div class="row mt-5">
            <div class="col-12">
                <?php echo $__env->make('back.pages.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">سفارشات</h3>
                        <div class="card-tools">
                            <div class="input-group input-group-sm" style="width: 150px;">
                                <input type="text" name="table_search" class="form-control float-right" placeholder="جستجو">

                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                </div>
                            </div>

                        </div>


                    </div>
                    <!-- /.card-header -->

                    <div id="loading">
                        <vue-simple-spinner class="mt4" size="large" message="Loading..."></vue-simple-spinner>
                    </div>
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover" style="font-size: 16px;">
                            <tbody>
                                <tr>
                                    <th>آیدی</th>
                                    <th>آیدی سفارش دهنده</th>
                                    <th>مبلغ پرداختی</th>
                                    <th>وضعیت</th>
                                    <th>وضعیت حمل ونقل</th>
                                    <th>نام سفارش دهنده</th>
                                    <th>آدرس</th>
                                    <th>شهر</th>
                                    <th>استان</th>
                                    <th>تلفن</th>
                                    <th>کدپستی</th>
                                    <th>تارییخ</th>
                                    <th>عملیات</th>
                                </tr>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="order-table">
                                        <td><?php echo e($order->id); ?></td>
                                        <td><?php echo e($order->user_id); ?></td>
                                        <td><?php echo e(number_format($order->grand_total)); ?></td>
                                        <td>
                                            <?php if($order->status == 'pending'): ?>
                                                <span><span class="badge badge-warning">در حال برسی</span></span>
                                            <?php endif; ?>
                                            <?php if($order->status == 'paid'): ?>
                                                <span><span class="badge badge-success">پرداخت شده</span></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($order->Shipping_status == 0): ?>
                                                <a href="<?php echo e(route('order.edit.shipping.status.admin.panel', $order->id)); ?>"><span class="badge badge-warning">ارسال نشده</span></a>
                                            <?php endif; ?>
                                            <?php if($order->Shipping_status == 1): ?>
                                                <a href="<?php echo e(route('order.edit.shipping.status.admin.panel', $order->id)); ?>"><span class="badge badge-success">ارسال شده</span></a>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($order->shopping_fullname); ?></td>
                                        <td><?php echo e($order->shopping_address); ?></td>
                                        <td><?php echo e($order->shopping_city); ?></td>
                                        <td><?php echo e($order->shopping_state); ?></td>
                                        <td><?php echo e($order->shopping_phone); ?></td>
                                        <td><?php echo e($order->shopping_zipcode); ?></td>
                                        <td><?php echo e($order->created_at); ?></td>
                                        <td><a href="<?php echo e(route('order.show.admin.panel', $order->id)); ?>" class="btn btn-primary"><i class="fas fa-eye"></i></a></td>
                                    </tr>
                                    <table class="table table-hover" style="font-size: 16px; width: 100%;">


                                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <ul class="order-table-list">
                                                <li><span>آیدی محصول</span>: <?php echo e($item->id); ?></li>
                                                <li><span>نام محصول</span>: <?php echo e($item->name); ?></li>
                                                <li><span>قیمت محصول</span>: <?php echo e(number_format($item->price)); ?> تومان</li>
                                                <li><span>تعداد محصول</span>: <?php echo e($item->pivot->quantity); ?></li>
                                            </ul>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->

            </div>



        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/back/pages/orders.blade.php ENDPATH**/ ?>