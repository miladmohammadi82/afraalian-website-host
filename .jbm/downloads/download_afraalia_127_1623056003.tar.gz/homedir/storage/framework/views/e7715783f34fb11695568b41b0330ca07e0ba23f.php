<?php $__env->startSection('content'); ?>
<section id="top-sale">
    <div class="container">
        <br>
        <br>
        <br>
        <br>
        <br>



            <?php if(!request()->input('query')): ?>
                <p class="alert alert-danger">محصولی پیدا نشد</p>
            <?php else: ?>


                <div class="result-text">
                    <h1>  جستجو "<?php echo e(request()->input('query')); ?>"</h1>
                </div>
                <p class="alert alert-warning"><?php echo e($count); ?> مورد پیدا شد </p>
                <div class="items-product-show-category">



                    <ul class="product_list">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li>
                                <div class="product-container">
                                    <div class="pro_first_box">
                                        <div class="product_img_link">
                                            <a href="<?php echo e(route('show.product.index.page', $product->slug)); ?>">
                                                <img class="img-responsive front-image " src="<?php echo e($product->index_image); ?>"
                                                    alt="<?php echo e($product->name); ?>" title="<?php echo e($product->name); ?>" width="273"
                                                    height="273">
                                            </a>
                                        </div>
                                        <div class="pro_second_box">
                                            <div class="s_title_block">
                                                <a href="<?php echo e(route('show.product.index.page', $product->slug)); ?>"
                                                    class="product-name"><?php echo e($product->name); ?></a>
                                            </div>
                                            <div class="price_container">
                                                <span class="price product-price"><?php echo e(number_format($product->price)); ?> تومان</span>
                                            </div>

                                        </div>
                                        <form action="<?php echo e(route('carte.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                            <input type="hidden" name="index_image" value="<?php echo e($product->index_image); ?>">
                                            <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                                            <input type="hidden" name="price" value="<?php echo e($product->price); ?>">
                                            <input type="hidden" name="quantity" value="1">

                                            <input type="submit" class="btn addtocart-btn cursor-pointer mb-4 mt-3"
                                                value="افزودن به سبد" accesskey="s">
                                        </form>
                                    </div>

                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    
            <?php endif; ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/front/pages/search-result.blade.php ENDPATH**/ ?>