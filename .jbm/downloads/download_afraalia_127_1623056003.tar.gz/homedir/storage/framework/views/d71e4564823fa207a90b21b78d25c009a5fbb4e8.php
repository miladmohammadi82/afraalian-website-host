<?php $__env->startSection('contentAdmin'); ?>

    <div class="container">
        <div class="row mt-5">
            <div class="col-12">
                <?php echo $__env->make('back.pages.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">کاربران این وبسایت</h3>
                        <a href="<?php echo e(route('newUser.admin.panel')); ?>" class="btn btn-success mt-4">
                            <i class="fas fa-user-plus"></i>&nbsp;افزودن کاربر
                        </a>
                        <div class="card-tools">
                            <div class="input-group input-group-sm" style="width: 150px;">
                                <input type="text" name="table_search" class="form-control float-right" placeholder="جستجو">

                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                </div>
                            </div>

                        </div>


                    </div>
                    <!-- /.card-header -->

                    <div id="loading">
                        <vue-simple-spinner class="mt4" size="large" message="Loading..."></vue-simple-spinner>
                    </div>
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover" style="font-size: 16px;">
                            <tbody>
                                <tr>
                                    <th>آیدی</th>
                                    <th>کاربر</th>
                                    <th>تاریخ ثبت نام</th>
                                    <th>وضعیت</th>
                                    <th>نقش</th>
                                    <th>عملیات</th>
                                </tr>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr >
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->created_at); ?></td>
                                        <td><span class="badge badge-success">تایید شده</span></td>
                                        <td>
                                            <?php if($user->role == 3): ?>
                                                <span class="badge badge-secondary">کاربر ساده</span>
                                            <?php endif; ?>
                                            <?php if($user->role == 2): ?>
                                                <span class="badge badge-info">ادمین</span>
                                            <?php endif; ?>
                                            <?php if($user->role == 1): ?>
                                                <span class="badge badge-warning">مالک</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('editUser.admin.panel' ,$user->id)); ?>" class="btn btn-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>&nbsp;
                                            <form method="POST" action="<?php echo e(route('destroyUser.admin.panel', $user->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-danger">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->

            </div>



        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/back/pages/users.blade.php ENDPATH**/ ?>