<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<div class="container container-cart-page">


    <div class="contact-form-box">
        <div class="item-mored-niaz-forPay">
            <div class="addres-girande-box">

                <?php echo $__env->make('back.pages.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <br>

                <div class="title-contact-page">
                    <h5>تماس با فلانی</h5>
                </div>

                <div class="contact-form-filds ">
                    <form action="<?php echo e(route('store.contact.page')); ?>" method="POST" class="row">
                        <?php echo csrf_field(); ?>
                        <div class="form-group col-lg-12">
                            <label for="">نام و نام خانوادگی <span class="text-danger">*</span></label>
                            <input type="text" value="<?php echo e(old('name')); ?>" class="mt-2 form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="نام و نام خانوادگی" name="name" id="">

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group col-lg-6">
                            <label for="">ایمیل <span class="text-danger">*</span></label>
                            <input type="email" value="<?php echo e(old('email')); ?>" class="mt-2 form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="ایمیل" name="email" id="">

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group col-lg-6">
                            <label for="">تلفن تماس <span class="text-danger">*</span></label>
                            <input type="text" value="<?php echo e(old('phone')); ?>" class="mt-2 form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="تلفن تماس" name="phone" id="">

                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group col-lg-12 ">
                            <label for="">متن پیام <span class="text-danger">*</span></label>
                            <textarea class="mt-2 form-control textarea-cantact-page <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="متن پیام خود را بنویسید ..." name="body" cols="30" rows="10"><?php echo e(old('body')); ?></textarea>

                                <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                        <div class="btn-save-info-edit-user">
                            <button type="submit" class="btn btn-primary">ارسال</button>
                        </div>
                    </form>
                </div>

            </div>


            <div class="addres-contact-page">
                <h5><i class="far fa-map-signs fa-3x"></i>آدرس</h5>
                <div class="addres-box-contact-page pt-4 row">

                    <div class="addres-section-cotact-page col-lg-6 col-md-6 d-flex justify-content-center">
                        <p>
                            گیلان، صومعه سرا، گوراب زرمیخ، سه راهی طتف، نرسیده به مسجد
                        </p>
                    </div>
                    <div class="mt-sm-4 map-addres-section-cotact-page col-lg-6 col-md-6 d-flex justify-content-center">
                        <div class="map-box-addres"></div>
                    </div>


                </div>
            </div>


            <div class="router-contact-this-web">
                <h5>راه های ارتباط باما</h5>
                <div class="router-contact-items">
                    <ul>
                        <li class="col-lg-4">
                            <div class="icon-box-contact-page">
                                <i class="fas fa-phone-alt fa-2x"></i>
                            </div>
                            <div class="title-contact-page">
                                <h6>تماس بگیرید</h6>
                                <small>013-34704745</small>
                            </div>
                        </li>

                        <li class="col-lg-4">
                            <div class="icon-box-contact-page">
                                <i class="far fa-at fa-2x"></i>
                            </div>
                            <div class="title-contact-page">
                                <h6>ایمیل</h6>
                                <small>info@afraalian.com</small>
                            </div>
                        </li>
                        <li class="col-lg-4">
                            <div class="icon-box-contact-page">
                                <i class="far fa-clock fa-2x"></i>
                            </div>
                            <div class="title-contact-page">
                                <h6>ساعت کاری</h6>
                                <small>۲۴ ساعت شبانه‌روز پاسخگوی شما هستیم</small>
                            </div>
                        </li>
                    </ul>
                </div>


            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/front/pages/contactPage.blade.php ENDPATH**/ ?>