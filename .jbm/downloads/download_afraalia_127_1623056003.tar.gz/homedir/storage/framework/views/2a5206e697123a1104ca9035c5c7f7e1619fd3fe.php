<?php $__env->startSection('adminContent'); ?>

<br>
<br>
<br>

<div class="show-address-user-checkout">
    <div class="show-address-user-checkout-content">
        <div class="show-address-user-checkout-title">آدرس تحویل سفارش</div>

        <ul class="show-address-user-checkout-items">
            <li><i class="far fa-map-marked-alt"></i> <?php echo e($addresses->address); ?></li>
            <li><i class="far fa-user"></i> <?php echo e($addresses->fullname); ?></li>
            <li><i class="far fa-phone"></i> <?php echo e($addresses->phone); ?></li>
            <li><i class="far fa-mailbox"></i> <?php echo e($addresses->zipcode); ?></li>
            <!-- Button trigger modal -->
            <li><a href="<?php echo e(route('edit.address.user.profile', $addresses->id)); ?>">ویرایش آدرس</a></li>
        </ul>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/profile/address/address.blade.php ENDPATH**/ ?>