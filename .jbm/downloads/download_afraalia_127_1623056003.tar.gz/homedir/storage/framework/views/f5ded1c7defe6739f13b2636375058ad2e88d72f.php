<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<main class="main-site">

        <section class="banner-arias" id="banner-aria">
            <div class="container-fluid">
                <div class="swiper-container img">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <img class="w-100" style="border-radius: 20px" src="<?php echo e(asset('assets/slider/banner1.jpg')); ?>" >
                        </div>
                        <div class="swiper-slide">
                            <img class="w-100" style="border-radius: 20px" src="<?php echo e(asset('assets/slider/banner2.jpg')); ?>" >
                        </div>
                        <div class="swiper-slide">
                            <img class="w-100" style="border-radius: 20px" src="<?php echo e(asset('assets/slider/banner3.jpg')); ?>" >
                        </div>
                    </div>
                    <div class="swiper-pagination swiper-pagination-white"></div>
                    <div class="swiper-button-next swiper-button-white"></div>
                    <div class="swiper-button-prev swiper-button-white"></div>
                </div>
            </div>
        </section>

        <!-- Start servisess -->
        <div class="container-fluid">
            <div class="servisess">
                <div class="items-servisess">
                    <div class="servisess-item">
                        <div class="aio-icon-default">
                            <img width="100px" src="../assets/image-servisess/free-send.svg" alt="">
                        </div>

                        <div class="aio-icon-header">
                            <p>ارسال رایگان</p>
                        </div>

                        <div class="aio-icon-description">
                            <small>
                                ارسال رایگان در سراسر کشور درب منزل
                            </small>
                        </div>
                    </div>

                    <div class="servisess-item">
                        <div class="aio-icon-default">
                            <img width="100px" src="../assets/image-servisess/rerurn-product.svg" alt="">
                        </div>

                        <div class="aio-icon-header">
                            <p>ضمانت بازگشت وجه</p>
                        </div>

                        <div class="aio-icon-description">
                            <small>
                                اگه از عسلمون راضی نبودید پولتون رو بر میگردونیم
                            </small>
                        </div>
                    </div>

                    <div class="servisess-item">
                        <div class="aio-icon-default">
                            <img width="100px" src="../assets/image-servisess/support-24.svg" alt="">
                        </div>

                        <div class="aio-icon-header">
                            <p>پشتیبانی بسیار سریع</p>
                        </div>

                        <div class="aio-icon-description">
                            <small>
                                در 24 ساعت شبانه روز در خدمتتون هستیم
                            </small>
                        </div>
                    </div>

                    <div class="servisess-item">
                        <div class="aio-icon-default">
                            <img width="100px" src="../assets/image-servisess/tarxk-time.svg" alt="">
                        </div>

                        <div class="aio-icon-header">
                            <p>ارسال سریع</p>
                        </div>

                        <div class="aio-icon-description">
                            <small>
                                ارسال بسیار سریع
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End servisess -->

        <!-- Start Slider product -->
        <br>
        <br>
        <section id="top-sale">
            <div class="container mt-3">
                <div class="row">
                    <div class="col-12">
                        <h4>
                            <span>محصولات ما</span>
                        </h4>

                        <div class="card-body">
                            <div class="owl-carousel owl-theme">

                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="product-item">

                                        <div class="panel-custom">
                                            <a href="<?php echo e(route('show.product.index.page', $product->slug)); ?>">
                                                <div class="panel-body-custom">
                                                    <img src="<?php echo e($product->index_image); ?>" alt="">
                                                </div>

                                            <div class="footer-section-product card-footer panel-footer-custom">


                                                <h4><?php echo e($product->name); ?></h4>
                                                <?php if(!is_null($product->previous_price)): ?>
                                                    <p><del class="text-danger" style="font-size: 13px"><?php echo e(number_format($product->previous_price)); ?>تومان</p></del>
                                                <?php endif; ?>

                                                <p><span><?php echo e(number_format($product->price)); ?></span>&ThinSpace;تومان</p>

                                            </a>
                                                <form action="<?php echo e(route('carte.store')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                                    <input type="hidden" name="index_image" value="<?php echo e($product->index_image); ?>">
                                                    <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                                                    <input type="hidden" name="price" value="<?php echo e($product->price); ?>">
                                                    <input type="hidden" name="quantity" value="1">

                                                    <input type="submit" class="btn addtocart-btn cursor-pointer" value="افزودن به سبد" accesskey="s">
                                                </form>




                                            </div>


                                        </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        




        <!-- END Slider product -->





<section id="top-sale">
    <div class="container mt-3">
        <div class="row">
            <div class="col-12">
                <h4>
                    <span>مطالب پربازدید</span>
                </h4>

                <div class="card-body">
                    <div class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $articlesPorbazdid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articlePorbazdid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="article-item">
                                <div class="panel-custom article-item-contents">
                                    <a href="<?php echo e(route('article.show.page', $articlePorbazdid->slug)); ?>">
                                        <div class="panel-body-custom">
                                            <img width="700" height="466" src="<?php echo e($articlePorbazdid->index_image); ?>" alt="">
                                        </div>
                                    </a>
                                    <div class="article-item-footer">
                                        <h4><?php echo e($articlePorbazdid->name); ?></h4>
                                        <div class="btns-action-article-item d-flex align-items-center justify-content-sm-around">
                                            <div class="like-article-item d-flex">
                                                <a>
                                                    <div class="harts-like">
                                                    <i class="fal fa-heart text-danger single-page__like <?php if($articlePorbazdid->is_user_liked): ?> fas <?php endif; ?>"></i>
                                                </div></a>                                            </div>
                                            <a class="btn d-flex align-items-center" href="<?php echo e(route('article.show.page', $articlePorbazdid->slug)); ?>">ادامه مطلب&nbsp;<i class="fas fa-chevron-left"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

</main>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>


    <script>
        $(".single-page__like").click(function () {
            fetch('<?php echo e(route("like.post", $articlePorbazdid->slug)); ?>', {
                method: "post",
                headers: {
                    'X-CSRF-Token': '<?php echo e(csrf_token()); ?>'
                }
            })

            .then(()=> {
                $(this).toggleClass("fas")
            })

        })
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/afraalia/resources/views/front/main.blade.php ENDPATH**/ ?>