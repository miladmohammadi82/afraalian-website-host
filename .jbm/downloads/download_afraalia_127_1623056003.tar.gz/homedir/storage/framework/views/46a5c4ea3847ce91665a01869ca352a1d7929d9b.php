<?php $__env->startSection('contentAdmin'); ?>

    <div class="container">
        <div class="row mt-5">
            <div class="col-12">
                <?php echo $__env->make('back.pages.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">محصولات این وبسایت</h3>
                        <a href="<?php echo e(route('newProductPage.admin.panel')); ?>" class="btn btn-success mt-4">
                            <i class="fas fa-user-plus"></i>&nbsp;افزودن محصول جدید
                        </a>
                        <div class="card-tools">
                            <div class="input-group input-group-sm" style="width: 150px;">
                                <input type="text" name="table_search" class="form-control float-right" placeholder="جستجو">

                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                </div>
                            </div>

                        </div>


                    </div>
                    <!-- /.card-header -->

                    <div id="loading">
                        <vue-simple-spinner class="mt4" size="large" message="Loading..."></vue-simple-spinner>
                    </div>
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover" style="font-size: 16px;">
                            <tbody>
                                <tr>
                                    <th>آیدی</th>
                                    <th>عنوان</th>
                                    <th>تصویر</th>
                                    <th>لینک</th>
                                    <th>دسته بندی ها</th>
                                    <th>وضعیت</th>
                                    <th>تارییخ ساخت</th>
                                </tr>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product->id); ?></td>
                                        <td><?php echo e($product->name); ?></td>
                                        <td><img width="50px" height="50px" src="<?php echo e($product->index_image); ?>"></td>
                                        <td><?php echo e($product->slug); ?></td>
                                        <td>
                                            <?php $__currentLoopData = $product->categories()->pluck('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge badge-dark"><?php echo e($category); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td>
                                            <?php if($product->active == 1): ?>
                                                <a href="<?php echo e(route('editActive.product.admin.panel', $product->id)); ?>"
                                                    class="border-0"><span class="badge badge-success">تایید شده</span></a>
                                            <?php endif; ?>
                                            <?php if($product->active == 0): ?>
                                                <a href="<?php echo e(route('editActive.product.admin.panel', $product->id)); ?>"><span
                                                        class="badge badge-danger">تایید نشده</span></a>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($product->created_at); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('edit.product.admin.panel', $product->id)); ?>"
                                                class="btn btn-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>&nbsp;
                                            <form method="POST"
                                                action="<?php echo e(route('destroy.product.admin.panel', $product->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-danger">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->

            </div>



        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/back/pages/products.blade.php ENDPATH**/ ?>