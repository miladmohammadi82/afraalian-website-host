<?php $__env->startSection('contentAdmin'); ?>


<div class="container">
    <div class="row mt-5">
        <div class="col-12">
            <?php echo $__env->make('back.pages.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">پیام های دریافتی توسط کاربران</h3>
                    <div class="card-tools">
                        <div class="input-group input-group-sm" style="width: 150px;">
                            <input type="text" name="table_search" class="form-control float-right" placeholder="جستجو">

                            <div class="input-group-append">
                                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                            </div>
                        </div>

                    </div>


                </div>
                <!-- /.card-header -->

                <div id="loading">
                    <vue-simple-spinner class="mt4" size="large" message="Loading..."></vue-simple-spinner>
                </div>
                <div class="card-body table-responsive p-0">
                    <table class="table table-hover" style="font-size: 16px;">
                        <tbody>
                            <tr>
                                <th>نام و نام خانوادگی</th>
                                <th>ایمیل</th>
                                <th>تلفن تماس</th>
                                <th>متن پیام</th>
                            </tr>
                            <?php $__currentLoopData = $contactMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contactMessage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($contactMessage->id); ?></td>
                                    <td><?php echo e($contactMessage->name); ?></td>
                                    <td><?php echo e($contactMessage->email); ?></td>
                                    <td><?php echo e($contactMessage->phone); ?></td>
                                    <td><?php echo e($contactMessage->body); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->

        </div>



    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/back/pages/contact-message.blade.php ENDPATH**/ ?>