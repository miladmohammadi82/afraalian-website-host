<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title'); ?>


<?php echo e($titleProduct); ?>


<?php $__env->stopSection(); ?>



    <section id="top-sale">
        <div class="container-fluid">
            <br>
            <br>
            <br>
            <br>
            

                    <div class="items-product-show-category">

                        <ul class="product_list">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li>
                                    <div class="product-container">
                                        <div class="pro_first_box">
                                            <div class="product_img_link">
                                                <a href="<?php echo e(route('show.product.index.page', $product->slug)); ?>">
                                                    <img class="img-responsive front-image " src="<?php echo e($product->index_image); ?>"
                                                        alt="<?php echo e($product->name); ?>" title="<?php echo e($product->name); ?>" width="273"
                                                        height="273">
                                                </a>
                                            </div>
                                            <div class="pro_second_box">
                                                <div class="s_title_block">
                                                    <a href="<?php echo e(route('show.product.index.page', $product->slug)); ?>"
                                                        class="product-name"><?php echo e($product->name); ?></a>
                                                </div>
                                                <div class="price_container">
                                                    <span class="price product-price"><?php echo e($product->price); ?> ریال</span>
                                                </div>

                                            </div>
                                            <form action="<?php echo e(route('carte.store')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                                <input type="hidden" name="index_image" value="<?php echo e($product->index_image); ?>">
                                                <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                                                <input type="hidden" name="price" value="<?php echo e($product->price); ?>">
                                                <input type="hidden" name="quantity" value="1">

                                                <input type="submit" class="btn addtocart-btn cursor-pointer mb-4 mt-3"
                                                    value="افزودن به سبد" accesskey="s">
                                            </form>
                                        </div>

                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>



                    </div>

            


            

                    <div class="items-article-show-category">

                        <ul class="article_list">
                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div class="article-item">
                                        <div class="panel-custom article-item-contents">
                                            <a href="<?php echo e(route('article.show.page', $article->slug)); ?>">
                                                <div class="panel-body-custom">
                                                    <img width="275" height="200" src="<?php echo e($article->index_image); ?>" alt="">
                                                </div>
                                            </a>
                                            <div class="article-item-footer">
                                                <h4><?php echo e($article->name); ?></h4>
                                                <div class="btns-action-article-item d-flex align-items-center justify-content-between">
                                                    <div class="like-article-item d-flex">

                                                    </div>
                                                    <a class="btn d-flex align-items-center" href="<?php echo e(route('article.show.page', $article->slug)); ?>">ادامه مطلب&nbsp;<i class="fas fa-chevron-left"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php echo e($articles->links()); ?>

                    </div>

            
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/front/pages/showProductCategory.blade.php ENDPATH**/ ?>