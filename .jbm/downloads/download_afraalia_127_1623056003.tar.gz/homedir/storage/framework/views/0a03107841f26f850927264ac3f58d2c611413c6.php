<?php $__env->startSection('content'); ?>

<div class="container-fluid d-flex justify-content-center">

    <div class="content-checkout-edit-addressPage">
        <div class="edit-box-header">
            <div class=""><h5>ویرایش جزئیات آدرس</h5></div>
        </div>

        <div class="edit-box-body">
            <form action="<?php echo e(route('update.checkout.page', $address->id)); ?>" method="post" id="send-info-checkout">
                <?php echo csrf_field(); ?>
                <div class="form-group group col-lg-12 w-100  mt-4">
                    <input class="input-checkout-priduct-info w-100" value="<?php echo e($address->fullname); ?>" name="shopping_fullname" type="text" required>
                    <span class="bar"></span>
                    <label class="label-checkout-priduct-info"><i class="fas fa-user"></i> نام و نام
                        خانوادگی*</label>
                    <?php $__errorArgs = ['shopping_fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group group col-lg-12 w-100  mt-4">
                    <input class="input-checkout-priduct-info w-100" value="<?php echo e($address->address); ?>" name="shopping_address" type="text"
                        required>
                    <span class="bar w-100"></span>
                    <label class="label-checkout-priduct-info w-100"><i class="fas fa-map-marker-alt"></i> آدرس*
                    </label>
                    <?php $__errorArgs = ['shopping_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="select-divs-addres mt-3">
                    <div class="form-group group col-lg-6 col-sm-12 col-md-12">
                        <label for="" class="pb-2" style="color: #7e7e7e">استان*</label>
                        <div class="search-select-box">
                            <select class="chosen-select-option"
                                name="shopping_state" data-live-search="true">
                                <option value="1">گیلان</option>
                                <option value="2">تهران</option>
                                <option value="3">اهواز</option>
                                <option value="4">گلستان</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group group col-lg-6 col-sm-12 col-md-12">
                        <label for="" class="pb-2" style="color: #7e7e7e">شهر*</label>

                        <div class="search-select-box">
                            <select class="chosen-select-option" name="shopping_city" id=""
                                data-live-search="true">
                                <option value="1">گیلان</option>
                                <option value="2">تهران</option>
                                <option value="3">اهواز</option>
                                <option value="4">گلستان</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="form-group group col-lg-12 w-100  mt-4">
                    <input class="input-checkout-priduct-info w-100" value="<?php echo e($address->zipcode); ?>" name="shopping_zipcode" type="text"
                        required>
                    <span class="bar w-100"></span>
                    <label class="label-checkout-priduct-info w-100"><i class="fas fa-location-arrow"></i> کد
                        پستی* </label>
                    <?php $__errorArgs = ['shopping_zipcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group group col-lg-12 w-100  mt-4">
                    <input class="input-checkout-priduct-info w-100" value="<?php echo e($address->phone); ?>" name="shopping_phone" type="text" required>
                    <span class="bar w-100"></span>
                    <label class="label-checkout-priduct-info w-100"><i class="fas fa-phone-alt"></i> شماره
                        تماس* </label>
                    <?php $__errorArgs = ['shopping_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="btn-group d-flex justify-content-end">
                    <button type="submit" class="btn btn-primary">
                        ویرایش
                    </button>
                </div>

            </form>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/front/pages/editAddressCheckout.blade.php ENDPATH**/ ?>