<?php $__env->startSection('adminContent'); ?>

<br>
<br>
<br>
<br>
<br>
<br>

<div class="container">
    <?php if(!$orders): ?>
        <br>
        <div class="alert alert-danger">شماهیچ نظری برای محصولات ثبت نکرده اید</div>
    <?php endif; ?>
    <table class="content-table">
        <thead>
            <tr>
                <th>محصولات سفارش داده شده</th>
                <th>کد سفارش</th>
                <th>تعداد</th>
                <th>قیمت کل</th>
                <th>وضغیت</th>
            </tr>
        </thead>
        <tbody class="tbody-mobile">
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <tr class="comment-table-mobile">
                        <td class="comment-table-mobile-td">
                            <h4>محصولات سفارش داده شده</h4>&nbsp;
                            <?php echo e($item->name); ?>

                        </td>
                        <td class="comment-table-mobile-td">
                            <h4>کد سفارش</h4>&nbsp;
                            <?php echo e($order->order_number); ?>

                        </td>
                        <td class="comment-table-mobile-td">
                            <h4>تعداد</h4>&nbsp;
                            <?php echo e($item->pivot->quantity); ?>

                        </td>
                        <td class="comment-table-mobile-td">
                            <h4>قیمت کل</h4>
                            <?php echo e(number_format($item->price)); ?>

                        </td>

                        <td class="comment-table-mobile-td">
                            <h4>وضغیت</h4>&nbsp;
                            <?php if($order->status == 'pending'): ?>
                                <span><span class="badge badge-warning">در حال برسی</span></span>
                            <?php endif; ?>
                            <?php if($order->status == 'paid'): ?>
                                <span><span class="badge badge-success">پرداخت شده</span></span>
                            <?php endif; ?>
                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/profile/orders/orders.blade.php ENDPATH**/ ?>