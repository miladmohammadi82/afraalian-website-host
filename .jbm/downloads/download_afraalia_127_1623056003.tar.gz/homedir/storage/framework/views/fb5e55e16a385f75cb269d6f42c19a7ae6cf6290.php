<?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/back/pages/layouts/message.blade.php ENDPATH**/ ?>