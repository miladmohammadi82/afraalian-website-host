


<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="product-commentRow" id="product-commentRow">
        <div class="product-comment">

            <img class="avatar" alt="" src="<?php echo e(asset('assets/images_min/d41d8cd98f00b204e9800998ecf8427e-min.jpg')); ?>" width="64" height="64">
            <div class="flex-grow-1 mt-4" style="padding-right: 10px">

                    <div class="mb-2">
                        <h6 class="ml-2 mb-0 name-user-product-comment"><?php echo e($comment->name); ?></h6>
                    </div>
                    <div>
                        <span class="commentContent"><?php echo e($comment->body); ?></span>
                        <a class="replyItem" id="replyItem" style="float: left;padding: 30px 0 0 0;">
                            پاسخ به نظر
                        </a>
                        <form action="<?php echo e(route('create.new.replay-article')); ?>" method="POST" class="reply-comment-product mt-4">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="parent_id" value="<?php echo e($comment->id); ?>">
                            <input type="hidden" name="article_id" value="<?php echo e($article->id); ?>">

                            <div class="form-group">
                                <label for="" class="pb-2">پاسخ خود را بنویسید...</label>
                                <textarea name="body" class="form-control" cols="30" rows="10"></textarea>
                            </div>
                            <div class="btn-group">
                                <button type="submit" class="btn btn-dark">ارسال</button>
                            </div>
                        </form>
                    </div>


                <?php echo $__env->make('front.pages.comments.comment', ['comments' => $comment->replies], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>


        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/front/pages/comments/comment.blade.php ENDPATH**/ ?>