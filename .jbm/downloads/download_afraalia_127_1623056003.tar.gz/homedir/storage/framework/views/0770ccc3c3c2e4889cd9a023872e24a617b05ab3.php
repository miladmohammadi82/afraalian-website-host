<?php $__env->startSection('content'); ?>

<br>
<br>
<br>
<br>
<br>

<div class="container">
    <div class="alert alert-success">
        پرداخت با موفقیت انجام شد محصول شما به زودی براتون ارسال میشه
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arfaalian-web\afraalian-backEnd\resources\views/front/pages/success/successPay.blade.php ENDPATH**/ ?>